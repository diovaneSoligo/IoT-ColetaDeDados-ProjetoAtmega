/*
  Tensao.h - Biblioteca para sensor de tensao eletrica.
  Criado por Marcelo Cuin - Julho/2012.
  mcuin@terra.com.br  |  @marcelocuin
*/

#ifndef Tensao_h
#define Tensao_h

#if defined(ARDUINO) && ARDUINO >= 100
  #include "Arduino.h"
#else
  #include "WProgram.h"
  #include <pins_arduino.h>
#endif

class Tensao {
  public:
    Tensao(int porta);
    float valor();
    float media();
  private:
    int _porta;
};

#endif
