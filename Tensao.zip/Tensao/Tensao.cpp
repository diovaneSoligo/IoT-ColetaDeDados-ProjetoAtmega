/*
  Tensao.cpp - Biblioteca para sensor de tensao eletrica.
  Criado por Marcelo Cuin - Julho/2012.
  mcuin@terra.com.br  |  @marcelocuin
*/

#include "Tensao.h"

Tensao::Tensao(int porta) {
  _porta = porta;
}

float Tensao::valor() {
  float val = 0.00;
  int valor = analogRead(_porta);
  if ((valor > 100) & (valor < 650)) {
     val = ((analogRead(_porta) * 5.000)/1024)*53;
  }
  if ((valor > 651) & (valor < 1023)) {
     val = ((analogRead(_porta) * 5.000)/1024)*49;
  }
  return val;
}

float Tensao::media() {
  float val = 0.00;
  float media = 0.00;
  int i;
  for (i=1; i<=3000; i++) {
      int valor = analogRead(_porta);
      if ((valor > 100) & (valor < 650)) {
         val = ((analogRead(_porta) * 5.000)/1024)*53;
      }
      if ((valor > 651) & (valor < 1023)) {
         val = ((analogRead(_porta) * 5.000)/1024)*49;
      }
      media = media + val;
      delay(1);
  }
  media = media / 3000;
  return media;
}
